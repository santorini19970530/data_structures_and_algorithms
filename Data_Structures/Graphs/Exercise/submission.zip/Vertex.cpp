#include "Vertex.hpp"

Vertex::Vertex(std::string _name){
    name = _name;
}
