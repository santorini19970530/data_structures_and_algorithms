#include "Edge.hpp"

Edge::Edge(Vertex *_from, Vertex *_to, int _weight){
    from = _from;
    to = _to;
    weight = _weight;
}
